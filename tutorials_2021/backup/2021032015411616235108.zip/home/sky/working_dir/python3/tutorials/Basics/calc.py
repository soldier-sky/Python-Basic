#example program for calculator

x=int(input("Plese enter first number: "))
y=int(input("Please enter second number: "))

result=x+y
print("Addition of "+ str(x) + " " + str(y) +" is " + str(result) ) 


