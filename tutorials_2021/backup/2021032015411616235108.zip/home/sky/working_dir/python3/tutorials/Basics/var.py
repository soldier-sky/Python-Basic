#example program to familiarize with variables

i=5
print(i)
i=i+1
print(i)

s='''this is a multi-line string.
This i the second line.'''
print(s)
