print("Welcome to python tutorial")
name= input("Please enter your name: ")

print("Hello " + name)
